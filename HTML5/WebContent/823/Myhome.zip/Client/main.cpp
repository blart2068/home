#include <QtGui/QApplication>
#include "dialog.h"
#define  TEST  0
#define  Port_R   4100      //接收端口
#define  Port_S   4000      //发送端口

bool  stus=0;
union mess msg;

int sockClient;
socklen_t len_S;
struct sockaddr_in addrSrv_S;

void *thread_func(void *)
{
    int sockSrv;
    struct sockaddr_in addrSrv_R;
    sockSrv = socket(AF_INET,SOCK_DGRAM,0);

    addrSrv_R.sin_addr.s_addr = htonl(INADDR_ANY);
    addrSrv_R.sin_family = AF_INET;
    addrSrv_R.sin_port = htons(Port_R);

    bind(sockSrv,(struct sockaddr *)&addrSrv_R,sizeof(struct sockaddr));
    socklen_t len = sizeof(struct sockaddr);

    while(1)
    {
#if TEST
    cout<<"recvfroming"<<endl;
#endif
        if(0 > recvfrom(sockSrv,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_R,&len))
        {
            perror("Recv fail\n");
            stus = 0;
        }
        else
        {
            stus = 1;
        }
    }

    return NULL;
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Dialog w;

    sockClient = socket(AF_INET,SOCK_DGRAM,0);

    addrSrv_S.sin_addr.s_addr = inet_addr("127.0.0.1");
    addrSrv_S.sin_family = AF_INET;
    addrSrv_S.sin_port = htons(Port_S);

    len_S = sizeof(struct sockaddr);


    pthread_t thread;
    pthread_create(&thread,NULL,thread_func,NULL);

    w.show();
    return a.exec();
}
