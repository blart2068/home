#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <iostream>
#include <stdio.h>
#include <pthread.h>
#include <time.h>
#include <QTimer>
/*  UDP  */
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/select.h>

using namespace std;

struct address
{
    int  Num;			//编号
    int  Stus;			//状态
/*
char  wcroom;		//浴室		1
char  washroom;		//洗漱		2
char  meetroom;		//客厅		3
char  TVb;		//电视背景	4
char  cookroom;		//厨房		5
char  bedroom;		//卧室		6
char  bedb;		//床头灯		7
char  welcome;		//迎宾灯		8
char  gallery;		//餐厅走廊	9
char  veranda;		//阳台		0
                        //All_on        11
                        //All_off       10
*/
};

union  mess
{
        int  status;
        struct address ADDR;
};


namespace Ui {
    class Dialog;
}

class Dialog : public QDialog {
    Q_OBJECT
public:
    Dialog(QWidget *parent = 0);
    ~Dialog();

protected:
    void changeEvent(QEvent *e);

public slots:
    void MytimerDate();

private:
    Ui::Dialog *ui;
};

#endif // DIALOG_H
