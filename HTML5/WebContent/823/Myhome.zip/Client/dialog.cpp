#include "dialog.h"
#include "ui_dialog.h"
#define  TEST  0

extern  bool stus;
extern union mess msg;
extern int sockClient;
extern socklen_t len_S;
extern struct sockaddr_in addrSrv_S;


Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);

    QTimer *timer = new QTimer(this);  //新建定时器
    connect(timer,SIGNAL(timeout()),this,SLOT(MytimerDate()));//关联定时器计满信号和相应的槽函数

     timer->start(100);//定时器开始计时，其中1000表示1000ms即1秒

//    ui->BackGround->resize(600,400);
    ui->BackGround->setStyleSheet("border-image:url(./image/room.bmp)");    //让图片适合窗口大小

    ui->welcome->setStyleSheet("border-image:url(./image/off.tiff)");
    ui->meetroom->setStyleSheet("border-image:url(./image/off.tiff)");
    ui->bed1->setStyleSheet("border-image:url(./image/off.tiff)");
    ui->bed2->setStyleSheet("border-image:url(./image/off.tiff)");
    ui->bedroom->setStyleSheet("border-image:url(./image/off.tiff)");
    ui->cookroom->setStyleSheet("border-image:url(./image/off.tiff)");
    ui->gallery->setStyleSheet("border-image:url(./image/off.tiff)");
    ui->TVb1->setStyleSheet("border-image:url(./image/off.tiff)");
    ui->TVb2->setStyleSheet("border-image:url(./image/off.tiff)");
    ui->veranda->setStyleSheet("border-image:url(./image/off.tiff)");
    ui->washroom->setStyleSheet("border-image:url(./image/off.tiff)");
    ui->wcroon->setStyleSheet("border-image:url(./image/off.tiff)");

}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::changeEvent(QEvent *e)
{
    QDialog::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}
void Dialog::MytimerDate()
{
   if(stus)
   {
#if TEST
    cout<<msg.ADDR.Num<<endl;
    cout<<msg.ADDR.Stus<<endl;
#endif
    switch(msg.ADDR.Num)
    {
        case 0:             //阳台
        {
            if(msg.ADDR.Stus)
            {
                ui->veranda->setStyleSheet("border-image:url(./image/on.tiff)");
            }
            else
            {
                ui->veranda->setStyleSheet("border-image:url(./image/off.tiff)");             
            }
            msg.status = 0;
            if (0 > sendto(sockClient,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_S,len_S))
            {
                    perror("Send fail\r\n");
            }
            stus = 0;
            break;
        }
        case 1:             //浴室
        {
            if(msg.ADDR.Stus)
            {
                ui->wcroon->setStyleSheet("border-image:url(./image/on.tiff)");
            }
            else
            {
                ui->wcroon->setStyleSheet("border-image:url(./image/off.tiff)");       
            }
            msg.status = 1;
            if (0 > sendto(sockClient,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_S,len_S))
            {
                    perror("Send fail\r\n");
            }
            stus = 0;
            break;
        }
        case 2:             //洗漱
        {
            if(msg.ADDR.Stus)
            {
                ui->washroom->setStyleSheet("border-image:url(./image/on.tiff)");
            }
            else
            {
                ui->washroom->setStyleSheet("border-image:url(./image/off.tiff)");
            }
            msg.status = 2;
            if (0 > sendto(sockClient,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_S,len_S))
            {
                    perror("Send fail\r\n");
            }
            stus = 0;
            break;
        }
        case 3:             //客厅
        {
            if(msg.ADDR.Stus)
            {
                ui->meetroom->setStyleSheet("border-image:url(./image/on.tiff)");
            }
            else
            {
                ui->meetroom->setStyleSheet("border-image:url(./image/off.tiff)");
            }
            msg.status = 3;
            if (0 > sendto(sockClient,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_S,len_S))
            {
                    perror("Send fail\r\n");
            }
            stus = 0;
            break;
        }
        case 4:             //电视背景
        {
            if(msg.ADDR.Stus)
            {
                ui->TVb1->setStyleSheet("border-image:url(./image/on.tiff)");
                ui->TVb2->setStyleSheet("border-image:url(./image/on.tiff)");
            }
            else
            {
                ui->TVb1->setStyleSheet("border-image:url(./image/off.tiff)");
                ui->TVb2->setStyleSheet("border-image:url(./image/off.tiff)");
            }
            msg.status = 4;
            if (0 > sendto(sockClient,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_S,len_S))
            {
                    perror("Send fail\r\n");
            }
            stus = 0;
            break;
        }
        case 5:             //厨房
        {
            if(msg.ADDR.Stus)
            {
                ui->cookroom->setStyleSheet("border-image:url(./image/on.tiff)");
            }
            else
            {
                ui->cookroom->setStyleSheet("border-image:url(./image/off.tiff)");
            }
            msg.status = 5;
            if (0 > sendto(sockClient,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_S,len_S))
            {
                    perror("Send fail\r\n");
            }
            stus = 0;
            break;
        }
        case 6:             //卧室
        {
            if(msg.ADDR.Stus)
            {
                ui->bedroom->setStyleSheet("border-image:url(./image/on.tiff)");
            }
            else
            {
                ui->bedroom->setStyleSheet("border-image:url(./image/off.tiff)");
            }
            msg.status = 6;
            if (0 > sendto(sockClient,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_S,len_S))
            {
                    perror("Send fail\r\n");
            }
            stus = 0;
            break;
        }
        case 7:             //床头灯
        {
            if(msg.ADDR.Stus)
            {
                ui->bed1->setStyleSheet("border-image:url(./image/on.tiff)");
                ui->bed2->setStyleSheet("border-image:url(./image/on.tiff)");
            }
            else
            {
                ui->bed1->setStyleSheet("border-image:url(./image/off.tiff)");
                ui->bed2->setStyleSheet("border-image:url(./image/off.tiff)");
            }
            msg.status = 7;
            if (0 > sendto(sockClient,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_S,len_S))
            {
                    perror("Send fail\r\n");
            }
            stus = 0;
            break;
        }
        case 8:             //迎宾灯
        {
            if(msg.ADDR.Stus)
            {
                ui->welcome->setStyleSheet("border-image:url(./image/on.tiff)");
            }
            else
            {
                ui->welcome->setStyleSheet("border-image:url(./image/off.tiff)");
            }
            msg.status = 8;
            if (0 > sendto(sockClient,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_S,len_S))
            {
                    perror("Send fail\r\n");
            }
            stus = 0;
            break;
        }
        case 9:             //餐厅走廊
        {
            if(msg.ADDR.Stus)
            {
                ui->gallery->setStyleSheet("border-image:url(./image/on.tiff)");
            }
            else
            {
                ui->gallery->setStyleSheet("border-image:url(./image/off.tiff)");
            }
            msg.status = 9;
            if (0 > sendto(sockClient,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_S,len_S))
            {
                    perror("Send fail\r\n");
            }
            stus = 0;
            break;
        }
        case 10:             //全关
        {
            ui->welcome->setStyleSheet("border-image:url(./image/off.tiff)");
            ui->meetroom->setStyleSheet("border-image:url(./image/off.tiff)");
            ui->bed1->setStyleSheet("border-image:url(./image/off.tiff)");
            ui->bed2->setStyleSheet("border-image:url(./image/off.tiff)");
            ui->bedroom->setStyleSheet("border-image:url(./image/off.tiff)");
            ui->cookroom->setStyleSheet("border-image:url(./image/off.tiff)");
            ui->gallery->setStyleSheet("border-image:url(./image/off.tiff)");
            ui->TVb1->setStyleSheet("border-image:url(./image/off.tiff)");
            ui->TVb2->setStyleSheet("border-image:url(./image/off.tiff)");
            ui->veranda->setStyleSheet("border-image:url(./image/off.tiff)");
            ui->washroom->setStyleSheet("border-image:url(./image/off.tiff)");
            ui->wcroon->setStyleSheet("border-image:url(./image/off.tiff)");

            msg.status = 10;
            if (0 > sendto(sockClient,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_S,len_S))
            {
                    perror("Send fail\r\n");
            }
            stus = 0;
            break;
        }
        case 11:             //全开
        {
            ui->welcome->setStyleSheet("border-image:url(./image/on.tiff)");
            ui->meetroom->setStyleSheet("border-image:url(./image/on.tiff)");
            ui->bed1->setStyleSheet("border-image:url(./image/on.tiff)");
            ui->bed2->setStyleSheet("border-image:url(./image/on.tiff)");
            ui->bedroom->setStyleSheet("border-image:url(./image/on.tiff)");
            ui->cookroom->setStyleSheet("border-image:url(./image/on.tiff)");
            ui->gallery->setStyleSheet("border-image:url(./image/on.tiff)");
            ui->TVb1->setStyleSheet("border-image:url(./image/on.tiff)");
            ui->TVb2->setStyleSheet("border-image:url(./image/on.tiff)");
            ui->veranda->setStyleSheet("border-image:url(./image/on.tiff)");
            ui->washroom->setStyleSheet("border-image:url(./image/on.tiff)");
            ui->wcroon->setStyleSheet("border-image:url(./image/on.tiff)");

            msg.status = 11;
            if (0 > sendto(sockClient,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_S,len_S))
            {
                    perror("Send fail\r\n");
            }
            stus = 0;
            break;
        }
     }
   }
}
