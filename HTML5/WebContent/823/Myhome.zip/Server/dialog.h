#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <iostream>
/*  UDP  */
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/select.h>
/*  Color  */
#include <QPalette>
#include <time.h>
#include <QTimer>

using namespace std;

struct address
{
        int  Num;			//编号
        int  Stus;			//状态
/*
        char  wcroom;		//浴室		1
        char  washroom;		//洗漱		2
        char  meetroom;		//客厅		3
        char  TVb;		//电视背景	4
        char  cookroom;		//厨房		5
        char  bedroom;		//卧室		6
        char  bedb;		//床头灯		7
        char  welcome;		//迎宾灯		8
        char  gallery;		//餐厅走廊	9
        char  veranda;		//阳台		0
                                //All_on        11
                                //All_off       10
*/
};

union  mess
{
        int  status;
        struct address ADDR;
};

namespace Ui {
    class Dialog;
}

class Dialog : public QDialog {
    Q_OBJECT
public:
    Dialog(QWidget *parent = 0);
    ~Dialog();

protected:
    void changeEvent(QEvent *e);

public slots:
    void MytimerDate();

private:
    Ui::Dialog *ui;    

private slots:
    void on_TVB_clicked();
    void on_bedB_clicked();
    void on_bedroom_clicked();
    void on_veranda_clicked();
    void on_wcroom_clicked();
    void on_washroom_clicked();
    void on_cookroom_clicked();
    void on_gallery_clicked();
    void on_meetroom_clicked();
    void on_welcome_clicked();
    void on_ALL_OFF_clicked();
    void on_ALL_ON_clicked();
};

#endif // DIALOG_H
