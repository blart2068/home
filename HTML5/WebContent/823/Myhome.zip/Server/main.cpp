#include <QtGui/QApplication>
#include "dialog.h"
#define  TEST  0

#define  Port_R   4000
#define  Port_S   4100

union mess msg;
int sockClient;
struct sockaddr_in addrSrv_S;
socklen_t  len_S;

bool  R_ok = 0;

/**********  pthread1  ***********/
void * thread_fun_R(void *)
{
    int sockSrv;
    struct sockaddr_in addrSrv_R;
    sockSrv = socket(AF_INET,SOCK_DGRAM,0);

    addrSrv_R.sin_addr.s_addr = htonl(INADDR_ANY);
    addrSrv_R.sin_family = AF_INET;
    addrSrv_R.sin_port = htons(Port_R);

    bind(sockSrv,(struct sockaddr *)&addrSrv_R,sizeof(struct sockaddr));
    socklen_t len_R = sizeof(struct sockaddr);

    while(1)
    {
#if TEST
        cout<<"Recving"<<endl;
#endif
        if(0 > recvfrom(sockSrv,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_R,&len_R))
        {
                perror("recvive fail!\n");
        }
#if TEST
        else
        {
                printf("recvive is--> %d\n",msg.status);
        }
#endif
        R_ok = 1;
    }
    close(sockSrv);
    return NULL;
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Dialog w;

    sockClient = socket(AF_INET,SOCK_DGRAM,0);
    addrSrv_S.sin_addr.s_addr = inet_addr("127.0.0.1");
    addrSrv_S.sin_family = AF_INET;
    addrSrv_S.sin_port = htons(Port_S);

    len_S = sizeof(struct sockaddr);

    pthread_t thread_R;
    if(0 > pthread_create(&thread_R,NULL,thread_fun_R,NULL))
    {
        perror("pthread fail\n");
    }
    else
                printf("pthread ok!\n");

    w.show();
    return a.exec();
}
