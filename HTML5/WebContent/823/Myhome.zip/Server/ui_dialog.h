/********************************************************************************
** Form generated from reading UI file 'dialog.ui'
**
** Created: Sun Dec 16 22:12:45 2012
**      by: Qt User Interface Compiler version 4.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_H
#define UI_DIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QPushButton *welcome;
    QPushButton *meetroom;
    QPushButton *cookroom;
    QPushButton *gallery;
    QPushButton *wcroom;
    QPushButton *washroom;
    QPushButton *veranda;
    QPushButton *bedroom;
    QPushButton *bedB;
    QPushButton *TVB;
    QPushButton *ALL_ON;
    QPushButton *ALL_OFF;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QString::fromUtf8("Dialog"));
        Dialog->resize(320, 240);
        Dialog->setStyleSheet(QString::fromUtf8("background-color: rgb(241, 253, 159);"));
        welcome = new QPushButton(Dialog);
        welcome->setObjectName(QString::fromUtf8("welcome"));
        welcome->setGeometry(QRect(20, 10, 70, 40));
        QFont font;
        font.setFamily(QString::fromUtf8("DejaVu Sans"));
        font.setPointSize(14);
        font.setBold(true);
        font.setWeight(75);
        welcome->setFont(font);
        welcome->setFocusPolicy(Qt::NoFocus);
        welcome->setFlat(true);
        meetroom = new QPushButton(Dialog);
        meetroom->setObjectName(QString::fromUtf8("meetroom"));
        meetroom->setGeometry(QRect(125, 10, 70, 40));
        meetroom->setFont(font);
        meetroom->setFocusPolicy(Qt::NoFocus);
        meetroom->setFlat(true);
        cookroom = new QPushButton(Dialog);
        cookroom->setObjectName(QString::fromUtf8("cookroom"));
        cookroom->setGeometry(QRect(20, 70, 70, 40));
        cookroom->setFont(font);
        cookroom->setFocusPolicy(Qt::NoFocus);
        cookroom->setFlat(true);
        gallery = new QPushButton(Dialog);
        gallery->setObjectName(QString::fromUtf8("gallery"));
        gallery->setGeometry(QRect(230, 10, 70, 40));
        gallery->setFont(font);
        gallery->setFocusPolicy(Qt::NoFocus);
        gallery->setFlat(true);
        wcroom = new QPushButton(Dialog);
        wcroom->setObjectName(QString::fromUtf8("wcroom"));
        wcroom->setGeometry(QRect(230, 70, 70, 40));
        wcroom->setFont(font);
        wcroom->setFocusPolicy(Qt::NoFocus);
        wcroom->setFlat(true);
        washroom = new QPushButton(Dialog);
        washroom->setObjectName(QString::fromUtf8("washroom"));
        washroom->setGeometry(QRect(125, 70, 70, 40));
        washroom->setFont(font);
        washroom->setFocusPolicy(Qt::NoFocus);
        washroom->setFlat(true);
        veranda = new QPushButton(Dialog);
        veranda->setObjectName(QString::fromUtf8("veranda"));
        veranda->setGeometry(QRect(20, 130, 70, 40));
        veranda->setFont(font);
        veranda->setFocusPolicy(Qt::NoFocus);
        veranda->setFlat(true);
        bedroom = new QPushButton(Dialog);
        bedroom->setObjectName(QString::fromUtf8("bedroom"));
        bedroom->setGeometry(QRect(125, 130, 70, 40));
        bedroom->setFont(font);
        bedroom->setFocusPolicy(Qt::NoFocus);
        bedroom->setFlat(true);
        bedB = new QPushButton(Dialog);
        bedB->setObjectName(QString::fromUtf8("bedB"));
        bedB->setGeometry(QRect(230, 130, 70, 40));
        bedB->setFont(font);
        bedB->setFocusPolicy(Qt::NoFocus);
        bedB->setFlat(true);
        TVB = new QPushButton(Dialog);
        TVB->setObjectName(QString::fromUtf8("TVB"));
        TVB->setGeometry(QRect(125, 190, 70, 40));
        TVB->setFont(font);
        TVB->setFocusPolicy(Qt::NoFocus);
        TVB->setFlat(true);
        ALL_ON = new QPushButton(Dialog);
        ALL_ON->setObjectName(QString::fromUtf8("ALL_ON"));
        ALL_ON->setGeometry(QRect(20, 190, 70, 40));
        ALL_ON->setFont(font);
        ALL_ON->setFocusPolicy(Qt::NoFocus);
        ALL_ON->setFlat(true);
        ALL_OFF = new QPushButton(Dialog);
        ALL_OFF->setObjectName(QString::fromUtf8("ALL_OFF"));
        ALL_OFF->setGeometry(QRect(230, 190, 70, 40));
        ALL_OFF->setFont(font);
        ALL_OFF->setFocusPolicy(Qt::NoFocus);
        ALL_OFF->setFlat(true);

        retranslateUi(Dialog);

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QApplication::translate("Dialog", "Dialog", 0, QApplication::UnicodeUTF8));
        welcome->setText(QApplication::translate("Dialog", "\351\227\250 \345\216\205", 0, QApplication::UnicodeUTF8));
        meetroom->setText(QApplication::translate("Dialog", "\345\256\242 \345\216\205", 0, QApplication::UnicodeUTF8));
        cookroom->setText(QApplication::translate("Dialog", "\345\216\250 \346\210\277", 0, QApplication::UnicodeUTF8));
        gallery->setText(QApplication::translate("Dialog", "\350\265\260 \345\273\212", 0, QApplication::UnicodeUTF8));
        wcroom->setText(QApplication::translate("Dialog", "\346\265\264 \345\256\244", 0, QApplication::UnicodeUTF8));
        washroom->setText(QApplication::translate("Dialog", "\346\264\227\346\274\261\351\227\264", 0, QApplication::UnicodeUTF8));
        veranda->setText(QApplication::translate("Dialog", "\351\230\263 \345\217\260", 0, QApplication::UnicodeUTF8));
        bedroom->setText(QApplication::translate("Dialog", "\345\215\247 \345\256\244", 0, QApplication::UnicodeUTF8));
        bedB->setText(QApplication::translate("Dialog", "\345\272\212\345\244\264\347\201\257", 0, QApplication::UnicodeUTF8));
        TVB->setText(QApplication::translate("Dialog", "\347\224\265 \350\247\206", 0, QApplication::UnicodeUTF8));
        ALL_ON->setText(QApplication::translate("Dialog", "\345\205\250 \345\274\200", 0, QApplication::UnicodeUTF8));
        ALL_OFF->setText(QApplication::translate("Dialog", "\345\205\250 \345\205\263", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_H
