#include "dialog.h"
#include "ui_dialog.h"

#define TEST  0

extern int sockClient;
extern struct sockaddr_in addrSrv_S;
extern socklen_t  len_S;
extern union mess msg;

int P_status[10] = {0,0,0,0,0,0,0,0,0,0};
extern bool R_ok;

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);

    ui->welcome->setStyleSheet("color: rgb(34, 34, 34)");
    ui->ALL_OFF->setStyleSheet("color: rgb(34, 34, 34)");
    ui->ALL_ON->setStyleSheet("color: rgb(34, 34, 34)");
    ui->bedB->setStyleSheet("color: rgb(34, 34, 34)");
    ui->bedroom->setStyleSheet("color: rgb(34, 34, 34)");
    ui->cookroom->setStyleSheet("color: rgb(34, 34, 34)");
    ui->gallery->setStyleSheet("color: rgb(34, 34, 34)");
    ui->meetroom->setStyleSheet("color: rgb(34, 34, 34)");
    ui->veranda->setStyleSheet("color: rgb(34, 34, 34)");
    ui->washroom->setStyleSheet("color: rgb(34, 34, 34)");
    ui->wcroom->setStyleSheet("color: rgb(34, 34, 34)");
    ui->TVB->setStyleSheet("color: rgb(34, 34, 34)");

    QTimer *timer = new QTimer(this);  //新建定时器
    connect(timer,SIGNAL(timeout()),this,SLOT(MytimerDate()));//关联定时器计满信号和相应的槽函数

    timer->start(100);//定时器开始计时，其中1000表示1000ms即1秒
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::changeEvent(QEvent *e)
{
    QDialog::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}
void Dialog::MytimerDate()
{
    if(R_ok)
    {
        switch(msg.status)
        {
            case 0:
            {
                if(P_status[0])
                    ui->veranda->setStyleSheet("color: rgb(255, 74, 225)");
                else
                    ui->veranda->setStyleSheet("color: rgb(34, 34, 34)");
                R_ok = 0;
                break;
            }
            case 1:
            {
                if(P_status[1])
                    ui->washroom->setStyleSheet("color: rgb(255, 74, 225)");
                else
                    ui->washroom->setStyleSheet("color: rgb(34, 34, 34)");
                R_ok = 0;
                break;
            }
            case 2:
            {
                if(P_status[2])
                    ui->wcroom->setStyleSheet("color: rgb(255, 74, 225)");
                else
                    ui->wcroom->setStyleSheet("color: rgb(34, 34, 34)");
                R_ok = 0;
                break;
            }
            case 3:
            {
                if(P_status[3])
                    ui->meetroom->setStyleSheet("color: rgb(255, 74, 225)");
                else
                    ui->meetroom->setStyleSheet("color: rgb(34, 34, 34)");
                R_ok = 0;
                break;
            }
            case 4:
            {
                if(P_status[4])
                    ui->TVB->setStyleSheet("color: rgb(255, 74, 225)");
                else
                    ui->TVB->setStyleSheet("color: rgb(34, 34, 34)");
                R_ok = 0;
                break;
            }
            case 5:
            {
                if(P_status[5])
                    ui->cookroom->setStyleSheet("color: rgb(255, 74, 225)");
                else
                    ui->cookroom->setStyleSheet("color: rgb(34, 34, 34)");
                R_ok = 0;
                break;
            }
            case 6:
            {
                if(P_status[6])
                    ui->bedroom->setStyleSheet("color: rgb(255, 74, 225)");
                else
                    ui->bedroom->setStyleSheet("color: rgb(34, 34, 34)");
                R_ok = 0;
                break;
            }
            case 7:
            {
                if(P_status[7])
                    ui->bedB->setStyleSheet("color: rgb(255, 74, 225)");
                else
                    ui->bedB->setStyleSheet("color: rgb(34, 34, 34)");
                R_ok = 0;
                break;
            }
            case 8:
            {
                if(P_status[8])
                    ui->welcome->setStyleSheet("color: rgb(255, 74, 225)");
                else
                    ui->welcome->setStyleSheet("color: rgb(34, 34, 34)");
                R_ok = 0;
                break;
            }
            case 9:
            {
                if(P_status[9])
                    ui->gallery->setStyleSheet("color: rgb(255, 74, 225)");
                else
                    ui->gallery->setStyleSheet("color: rgb(34, 34, 34)");
                R_ok = 0;
                break;
            }
/***********************************
            case 10:
            {

                    ui->ALL_OFF->setStyleSheet("color: rgb(255, 74, 225)");


                R_ok = 0;
                break;
            }
            case 11:
            {        ui->ALL_ON->setStyleSheet("color: rgb(34, 34, 34)");
                ui->ALL_OFF->setStyleSheet("color: rgb(34, 34, 34)");

                    ui->ALL_ON->setStyleSheet("color: rgb(255, 74, 225)");


                R_ok = 0;
                break;
            }
***********************************/
        }
    }
}

void Dialog::on_ALL_ON_clicked()
{
    msg.ADDR.Num = 11;
    msg.ADDR.Stus = 1;
#if TEST
        printf("%d %d\n",msg.ADDR.Num,msg.ADDR.Stus);
#endif
        if (0 > sendto(sockClient,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_S,len_S))
        {
                perror("Send fail\r\n");
        }
}

void Dialog::on_ALL_OFF_clicked()
{
    msg.ADDR.Num = 10;
    msg.ADDR.Stus = 0;
#if TEST
        printf("%d %d\n",msg.ADDR.Num,msg.ADDR.Stus);
#endif
        if (0 > sendto(sockClient,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_S,len_S))
        {
                perror("Send fail\r\n");
        }
}

void Dialog::on_welcome_clicked()
{
    msg.ADDR.Num = 8;
    if(P_status[8])
    {
            msg.ADDR.Stus = 0;
            P_status[8] = 0;
    }
    else
    {
            msg.ADDR.Stus = 1;
            P_status[8] = 1;
    }
#if TEST
        printf("%d %d\n",msg.ADDR.Num,msg.ADDR.Stus);
#endif
        if (0 > sendto(sockClient,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_S,len_S))
        {
                perror("Send fail\r\n");
        }
}

void Dialog::on_meetroom_clicked()
{
    msg.ADDR.Num = 3;
    if(P_status[3])
    {
            msg.ADDR.Stus = 0;
            P_status[3] = 0;
    }
    else
    {
            msg.ADDR.Stus = 1;
            P_status[3] = 1;
    }
#if TEST
        printf("%d %d\n",msg.ADDR.Num,msg.ADDR.Stus);
#endif
        if (0 > sendto(sockClient,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_S,len_S))
        {
                perror("Send fail\r\n");
        }
}

void Dialog::on_gallery_clicked()
{
    msg.ADDR.Num = 9;
    if(P_status[9])
    {
            msg.ADDR.Stus = 0;
            P_status[9] = 0;
    }
    else
    {
            msg.ADDR.Stus = 1;
            P_status[9] = 1;
    }
#if TEST
        printf("%d %d\n",msg.ADDR.Num,msg.ADDR.Stus);
#endif
        if (0 > sendto(sockClient,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_S,len_S))
        {
                perror("Send fail\r\n");
        }
}

void Dialog::on_cookroom_clicked()
{
    msg.ADDR.Num = 5;
    if(P_status[5])
    {
            msg.ADDR.Stus = 0;
            P_status[5] = 0;
    }
    else
    {
            msg.ADDR.Stus = 1;
            P_status[5] = 1;
    }
#if TEST
        printf("%d %d\n",msg.ADDR.Num,msg.ADDR.Stus);
#endif
        if (0 > sendto(sockClient,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_S,len_S))
        {
                perror("Send fail\r\n");
        }
}

void Dialog::on_washroom_clicked()
{
    msg.ADDR.Num = 1;
    if(P_status[1])
    {
            msg.ADDR.Stus = 0;
            P_status[1] = 0;
    }
    else
    {
            msg.ADDR.Stus = 1;
            P_status[1] = 1;
    }
#if TEST
        printf("%d %d\n",msg.ADDR.Num,msg.ADDR.Stus);
#endif
        if (0 > sendto(sockClient,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_S,len_S))
        {
                perror("Send fail\r\n");
        }
}

void Dialog::on_wcroom_clicked()
{
    msg.ADDR.Num = 2;
    if(P_status[2])
    {
            msg.ADDR.Stus = 0;
            P_status[2] = 0;
    }
    else
    {
            msg.ADDR.Stus = 1;
            P_status[2] = 1;
    }
#if TEST
        printf("%d %d\n",msg.ADDR.Num,msg.ADDR.Stus);
#endif
        if (0 > sendto(sockClient,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_S,len_S))
        {
                perror("Send fail\r\n");
        }
}

void Dialog::on_veranda_clicked()
{
    msg.ADDR.Num = 0;
    if(P_status[0])
    {
            msg.ADDR.Stus = 0;
            P_status[0] = 0;
    }
    else
    {
            msg.ADDR.Stus = 1;
            P_status[0] = 1;
    }
#if TEST
        printf("%d %d\n",msg.ADDR.Num,msg.ADDR.Stus);
#endif
        if (0 > sendto(sockClient,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_S,len_S))
        {
                perror("Send fail\r\n");
        }
}

void Dialog::on_bedroom_clicked()
{
    msg.ADDR.Num = 6;
    if(P_status[6])
    {
            msg.ADDR.Stus = 0;
            P_status[6] = 0;
    }
    else
    {
            msg.ADDR.Stus = 1;
            P_status[6] = 1;
    }
#if TEST
        printf("%d %d\n",msg.ADDR.Num,msg.ADDR.Stus);
#endif
        if (0 > sendto(sockClient,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_S,len_S))
        {
                perror("Send fail\r\n");
        }
}

void Dialog::on_bedB_clicked()
{
    msg.ADDR.Num = 7;
    if(P_status[7])
    {
            msg.ADDR.Stus = 0;
            P_status[7] = 0;
    }
    else
    {
            msg.ADDR.Stus = 1;
            P_status[7] = 1;
    }
#if TEST
        printf("%d %d\n",msg.ADDR.Num,msg.ADDR.Stus);
#endif
        if (0 > sendto(sockClient,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_S,len_S))
        {
                perror("Send fail\r\n");
        }
}

void Dialog::on_TVB_clicked()
{
    msg.ADDR.Num = 4;
    if(P_status[4])
    {
            msg.ADDR.Stus = 0;
            P_status[4] = 0;
    }
    else
    {
            msg.ADDR.Stus = 1;
            P_status[4] = 1;
    }
#if TEST
        printf("%d %d\n",msg.ADDR.Num,msg.ADDR.Stus);
#endif
        if (0 > sendto(sockClient,&msg,sizeof(msg),0,(struct sockaddr *)&addrSrv_S,len_S))
        {
                perror("Send fail\r\n");
        }
}
