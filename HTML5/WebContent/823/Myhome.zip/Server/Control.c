#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
/*  UDP  */
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/select.h>
#define  TEST  0

#define  Port_R   4000
#define  Port_S   4100        	  

struct address
{
	int  Num;			//编号
	int  Stus;			//状态
	//浴室		1
	//洗漱		2
	//客厅		3
	//电视背景	4
	//厨房		5
	//卧室		6
	//床头灯		7
	//迎宾灯		8
	//餐厅走廊	9
	//阳台		0
};

union  mess
{
	int  status;
	struct address ADDR;
};

int P_status[10] = {0,0,0,0,0,0,0,0,0,0};

/**********  pthread1  ***********/
void * thread_fun_R(void *arg)
{
	union mess MESS;
	
	int sockSrv;
	struct sockaddr_in addrSrv_R;
	sockSrv = socket(AF_INET,SOCK_DGRAM,0);
	
    addrSrv_R.sin_addr.s_addr = htonl(INADDR_ANY);
    addrSrv_R.sin_family = AF_INET;
    addrSrv_R.sin_port = htons(Port_R);
    
    bind(sockSrv,(struct sockaddr *)&addrSrv_R,sizeof(struct sockaddr));
    socklen_t len_R = sizeof(struct sockaddr);

    while(1)
    {
    	if(0 > recvfrom(sockSrv,&MESS,sizeof(MESS),0,(struct sockaddr *)&addrSrv_R,&len_R))
    	{
    		perror("recvive fail!\n");
    	}
#if TEST
    	else
    	{
    		printf("recvive is--> %d\n",MESS.status);
    	}
#endif
    }
    close(sockSrv);
    return NULL;
}

int main(void)
{
	int temp = 0;
	union mess MESS;
	/***   UDP   ***/
	int sockClient;
	struct sockaddr_in addrSrv_S;
	socklen_t  len_S;
	sockClient = socket(AF_INET,SOCK_DGRAM,0);	
    addrSrv_S.sin_addr.s_addr = inet_addr("127.0.0.1");
    addrSrv_S.sin_family = AF_INET;
    addrSrv_S.sin_port = htons(Port_S);
    
    len_S = sizeof(struct sockaddr);

//	MESS mes
	pthread_t thread_R;
    if(0 > pthread_create(&thread_R,NULL,thread_fun_R,NULL))
    {
    	perror("pthread fail\n");
    }
    else
   		printf("pthread ok!\n");
   		
	while(1)
	{
		scanf("%d",&temp);
		switch(temp)
		{
			case 0:
			{
				MESS.ADDR.Num = 0;
				if(P_status[0])
				{
					MESS.ADDR.Stus = 0;
					P_status[0] = 0;
				}
				else
				{
					MESS.ADDR.Stus = 1;
					P_status[0] = 1;
				}
				break;
			}
			case 1:
			{
				MESS.ADDR.Num = 1;
				if(P_status[1])
				{
					MESS.ADDR.Stus = 0;
					P_status[1] = 0;
				}
				else
				{
					MESS.ADDR.Stus = 1;
					P_status[1] = 1;
				}
				break;
			}
			case 2:
			{
				MESS.ADDR.Num = 2;
				if(P_status[2])
				{
					MESS.ADDR.Stus = 0;
					P_status[2] = 0;
				}
				else
				{
					MESS.ADDR.Stus = 1;
					P_status[2] = 1;
				}
				break;
			}
			case 3:
			{
				MESS.ADDR.Num = 3;
				if(P_status[3])
				{
					MESS.ADDR.Stus = 0;
					P_status[3] = 0;
				}
				else
				{
					MESS.ADDR.Stus = 1;
					P_status[3] = 1;
				}
				break;
			}
			case 4:
			{
				MESS.ADDR.Num = 4;
				if(P_status[4])
				{
					MESS.ADDR.Stus = 0;
					P_status[4] = 0;
				}
				else
				{
					MESS.ADDR.Stus = 1;
					P_status[4] = 1;
				}
				break;
			}
			case 5:
			{
				MESS.ADDR.Num = 5;
				if(P_status[5])
				{
					MESS.ADDR.Stus = 0;
					P_status[5] = 0;
				}
				else
				{
					MESS.ADDR.Stus = 1;
					P_status[5] = 1;
				}
				break;
			}
			case 6:
			{
				MESS.ADDR.Num = 6;
				if(P_status[6])
				{
					MESS.ADDR.Stus = 0;
					P_status[6] = 0;
				}
				else
				{
					MESS.ADDR.Stus = 1;
					P_status[6] = 1;
				}
				break;
			}
			case 7:
			{
				MESS.ADDR.Num = 7;
				if(P_status[7])
				{
					MESS.ADDR.Stus = 0;
					P_status[7] = 0;
				}
				else
				{
					MESS.ADDR.Stus = 1;
					P_status[7] = 1;
				}
				break;
			}
			case 8:
			{
				MESS.ADDR.Num = 8;
				if(P_status[8])
				{
					MESS.ADDR.Stus = 0;
					P_status[8] = 0;
				}
				else
				{
					MESS.ADDR.Stus = 1;
					P_status[8] = 1;
				}
				break;
			}
			case 9:
			{
				MESS.ADDR.Num = 9;
				if(P_status[9])
				{
					MESS.ADDR.Stus = 0;
					P_status[9] = 0;
				}
				else
				{
					MESS.ADDR.Stus = 1;
					P_status[9] = 1;
				}
				break;
			}
		}
#if TEST
		printf("%d %d\n",MESS.ADDR.Num,MESS.ADDR.Stus);
#endif
		if (0 > sendto(sockClient,&MESS,sizeof(MESS),0,(struct sockaddr *)&addrSrv_S,len_S))
		{		
			perror("Send fail\r\n");
		}
	}
	close(sockClient);
	return 0;
}
